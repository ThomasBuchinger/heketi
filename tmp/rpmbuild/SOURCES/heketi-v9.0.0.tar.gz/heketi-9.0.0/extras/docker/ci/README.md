# Overview
Dockerfile to build using code from this repo and test in a CI system

# Build
First build binaries and copy to this directory

    # docker build --rm --tag heketi/heketi:ci .

