# Overview
Dockerfile and helper build script to build a Heketi container
for Raspberry Pi from an x86_64 machine

# Build

```
$ ./build-rpi-dockerfile.sh
$ sudo docker push heketi/heketi-rpi
```

