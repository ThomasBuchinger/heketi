# Heketi Design Documents and Proposals

This directory contains Heketi design documents and accepted design proposals.
